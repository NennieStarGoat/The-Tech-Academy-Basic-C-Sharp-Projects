﻿using System;
using CarInsurance.Models;
using CarInsurance.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CarInsurance.Controllers
{
    public class InsuredController : Controller
    {
        private readonly InsuranceContext _context;
        public InsuredController(InsuranceContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var insurees = await _context.Insurees.ToListAsync();
            return View(insurees);
        }

        public async Task<IActionResult> Admin()
        {
            var insurees = await _context.Insurees.ToListAsync();
            return View(insurees);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id, FirstName, LastName, EmailAddress, DateOfBirth, CarYear, CarMake, CarModel, DUI, SpeedingTickets, CoverageType")] Insuree insuree)
        {
            if (ModelState.IsValid)
            {
                insuree.Quote = CalculateQuote(insuree);
                _context.Insurees.Add(insuree);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(insuree);
        }

            private decimal CalculateQuote(Insuree insuree)
        {
            decimal monthlytotal = 50m;
            int age = DateTime.Today.Year - insuree.DateOfBirth.Year;
            if (insuree.DateOfBirth > DateTime.Today.AddYears(-age))
            {
                age--;
            }
            if (age <= 18)
            {
                monthlytotal += 100m;
            }
            else if (age >= 19 && age <= 25)
            {
                monthlytotal += 50m;
            }
            else
            {
                monthlytotal += 25m;
            }

            if (insuree.CarYear < 2000 || insuree.CarYear > 2015)
            {
                monthlytotal += 25m;
            }

            if (!string.IsNullOrWhiteSpace(insuree.CarMake) && insuree.CarMake.Trim().Equals("Porsche", StringComparison.OrdinalIgnoreCase))
            {
                monthlytotal += 25m;

                if (!string.IsNullOrWhiteSpace(insuree.CarModel) && insuree.CarModel.Trim().Equals("911 Carrera", StringComparison.OrdinalIgnoreCase))
                {
                    monthlytotal += 25m;
                }
            }

            if (insuree.SpeedingTickets > 0)
            {
                monthlytotal += insuree.SpeedingTickets * 10m;
            }

            if (insuree.DUI)
            {
                monthlytotal *= 1.25m;
            }

            if (insuree.CoverageType)
            {
                monthlytotal *= 1.50m;
            }

            return Math.Round(monthlytotal, 2);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
